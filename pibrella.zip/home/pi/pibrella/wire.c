/*
 * wire.c:
 *	Guide a loop along a wire without touching it.
 *	Copyright (c) Gordon Henderson, 2014
 ***********************************************************************
 *    This is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with This.  If not, see <http://www.gnu.org/licenses/>.
 ***********************************************************************
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include <wiringPi.h>

#include "pibrella.h"


static void debounce (int pin)
{
  for (;;)
  {
    while (digitalRead (pin) == 1)
      delay (1) ;

    delay (20) ;

    if (digitalRead (pin) == 0)	// Clear
      break ;
  }
}

/*
 * main:
 ***********************************************************************
 */

int main (void)
{
  int touches ;

  wiringPiSetup () ;
  pibrellaSetup () ;

// We start with all LEDs off and ready to go. The button on the Pibrella
//	acts as the reset button

  for (;;)
  {
    touches = 0 ;
    digitalWrite (PIBRELLA_GREEN,  0) ;
    digitalWrite (PIBRELLA_YELLOW, 0) ;
    digitalWrite (PIBRELLA_RED,    0) ;
    playTone (0) ;

// Wait for the wire to be clear

    printf ("Waiting for the wire to be clear...\n") ;

    if (digitalRead (PIBRELLA_IN_A) == 1)
    {
      digitalWrite (PIBRELLA_RED, 1) ;
      debounce (PIBRELLA_IN_A) ;
    }
    digitalWrite (PIBRELLA_RED, 0) ;

// OK. Ready to roll

    printf ("OK. Ready to play!\n") ;

    for (;;)
    {
      if (digitalRead (PIBRELLA_BUTTON) == 1)	// Big Red Reset Button
	break ;

      if (digitalRead (PIBRELLA_IN_A) == 1)	// Touched
      {
	++touches ;
	printf ("Touched! Touch number: %d\n", touches) ;

	playTone (1000) ;

	if (touches == 1)
	  digitalWrite (PIBRELLA_GREEN, 1) ;	//	First life gone

	if (touches == 2)
	  digitalWrite (PIBRELLA_YELLOW, 1) ;	//	Second life gone

	if (touches == 3)
	  digitalWrite (PIBRELLA_RED, 1) ;	//	Third life gone

	if (touches == 4)
	{
	  delay (100) ;
	  playTone (250) ;
	  break ;
	}

	delay (100) ;
	playTone (0) ;

	debounce (PIBRELLA_IN_A) ;
      }
    }

// Broken out - game over or we've hit the reset button

    if (digitalRead (PIBRELLA_BUTTON) == 1)	// Big Red Reset Button
    {
      playTone (0) ;
      debounce (PIBRELLA_BUTTON) ;
      continue ;
    }

// Game over

    for (;;)
    {
      playTone (1000) ;
      delay (100) ;
      if (digitalRead (PIBRELLA_BUTTON) == 1)	// Big Red Reset Button
	break ;

      playTone (500) ;
      delay (100) ;
      if (digitalRead (PIBRELLA_BUTTON) == 1)	// Big Red Reset Button
	break ;
    }

    playTone (0) ;
  }

  return 0 ;
}
