/*
 * tune.c:
 *	Play a tune using the Pibrella buzzer
 *
 * Copyright (c) 2014 Gordon Henderson. <projects@drogon.net>
 ***********************************************************************
 *    This is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU Lesser General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public License
 *    along with This.  If not, see <http://www.gnu.org/licenses/>.
 ***********************************************************************
 */

#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <math.h>

#include <wiringPi.h>

#include "pibrella.h"

// Beats per minute

#define	TEMPO	120
#define	MS_PER_BEAT	((1000*60/TEMPO)/4)

// Simple scale frequencies

static const int scale [8] = { 262, 294, 330, 349, 392, 440, 494, 525 } ;

// Our tune: Note followed by duration in quarter crotchets

const int tune [] = 
{
  0,6, 1,2, 2,6, 0,2,		// Doe, a deer, a
   2,4, 0,4, 2,8,		//   fe - male deer,
  1,6, 2,2, 3,2, 3,2, 2,2, 1,2,	// ray, a drop of gold-en
   3,14, -1,2,			//   sun.
  2,6, 3,2, 4,6, 2,2,		// Me, a name I
   4,4, 2,4, 4,8,		//   call my - self
  3,6, 4,2, 5,2, 5,2, 4,2, 3,2,	// Far, a long, long way to
    5, 16,			//  run.
  4,6, 0,2, 1,2, 2,2, 3,2, 4,2,	// Sew, a nee - dle pull - ing
    5,14, -1,2,			// thread
  5,6, 1,2, 2,2, 3,2, 4,2, 5,2,	// La, a note to fol - low
   6,14, -1,2,			//  so.
  6,6, 2,2, 3,2, 4,2, 5,2, 6,2,	// Tea, a drink with jam and
   7,12, -1,4,			//  bread
  6,2, 6,2, 5,4, 4,4, 6,4, 4,4,	// that will bring us back to
  7,4, 4,4, 2,4, 1,4,		// do, oh, oh, oh!
  
  -1, 16, -1, -1
} ;


/*
 * main:
 *********************************************************************************
 */

int main (void)
{
  int note, dur ;
  int i ;

  wiringPiSetup () ;
  pibrellaSetup () ;

// Play the tune

  for (i = 0 ;; i += 2)
  {
    note = tune [i] ;
    dur  = tune [i + 1] ;
    if ((note == -1) && (dur == -1))
      break ;

    if (note == -1)	// Pause
      printf ("Rest  ") ;
    else
    {
      printf ("Note: %d  ", note) ;
      playTone (scale [note]) ;
    }

// Delay for the note duration

    printf ("Time: %4d\n", MS_PER_BEAT * dur) ;
    delay (MS_PER_BEAT * dur - 5) ;

// Stop sound for a few mS between notes

    playTone (0) ;
    delay    (5) ;
  }

  return 0 ;
}
